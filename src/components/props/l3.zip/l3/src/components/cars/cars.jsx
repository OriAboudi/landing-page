import axios from 'axios'
import React from 'react'
import { useState } from 'react'
import { useEffect } from 'react'

const Cars = () => {
    const [cars, setCars] = useState([])

    const doApi = async () => {
        let url = `https://project-yarin.herokuapp.com/cars?perPage=99`
        const resp = await axios.get(url);
        const data = resp.data
        console.log(data)
        setCars(data);
    }

    useEffect(() => {
        doApi();
        console.log(cars);
    }, [])


    return (

        <div>
       


            {cars[0]?._id &&
            <div>
                <p>
                    {cars[0].company}
                </p>
                <p>
                    {cars[1].company}
                </p>
                <p>
                    {cars[2].company}
                </p>
                <p>
                    {cars[3].company}
                </p>

            </div>
        }
        </div>
    )
}

export default Cars