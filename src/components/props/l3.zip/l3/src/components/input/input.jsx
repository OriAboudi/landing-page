import React, { useEffect, useState } from 'react'

import { useRef } from 'react'

const Input = () => {

  const [res, setRes] = useState("");
  const input = useRef()
  const selectRef = useRef();

/**
 * let input = document.getElementById('#input') 
 * let div = document.getElementById('div') 
 * let num = 0;
 * const init = () => {
 * num=10;
 * div.innerHTML = input.value;
 * }
 * 
 * init();
 * 
 */

//UseEffect == init(); && Listen to changes in the array

    useEffect(()=>{
       
    },[res])

  return (
    <div className='my-5 p-5 shadow border border-1 d-flex justify-content-center'>
      <div>
        <h1>Input:{res}</h1>
        <input value={res} onInput={()=>(setRes(input.current.value))}  type="text" ref={input} />
        <button onClick={() => setRes(input.current.value)}>submit</button>

        <select onChange={() => setRes(selectRef.current.value)} ref={selectRef} className='form-select mt-3'>
          <option value="Messi">Messi</option>
          <option value="CR7">CR7</option>
          <option value="Ronaldiho">Ronaldiho</option>
        </select>

      </div>
    </div>
  )
}

export default Input