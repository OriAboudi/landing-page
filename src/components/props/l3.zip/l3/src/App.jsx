import './App.css';
import Cars from './components/cars/cars';
import Input from './components/input/input';
import Parent from './components/props/parent';

function App() {
  return (
    <div >
     {/* <Parent/>
     <Input/> */}
     <Cars/>
    </div>
  );
}

export default App;
