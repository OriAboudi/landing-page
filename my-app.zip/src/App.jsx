
import './App.css';
import AppRouters from './routers/appRouters';

function App() {
  return (
    <div className="App">
      <AppRouters />
    </div>
  );
}

export default App;
